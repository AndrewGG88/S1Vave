// SPDX-License-Identifier: GPL-3.0-only
// S1Vave Tweak Synth Official Editor Engine (SDK 16)

(async () => {
  await vibe.ready;

  const ALIASES = {
    cutoff: ["cutoff", "filter_cutoff"],
    filter_cutoff: ["cutoff", "filter_cutoff"],
    reso: ["reso", "filter_reso"],
    filter_reso: ["reso", "filter_reso"],
    fenv_amt: ["fenv_amt", "filter_env_amt"],
    filter_env_amt: ["fenv_amt", "filter_env_amt"],
    flfo_amt: ["flfo_amt", "filter_lfo_amt"],
    filter_lfo_amt: ["flfo_amt", "filter_lfo_amt"],
    key_follow: ["key_follow", "keytrk", "filter_key_follow"],
    filter_key_follow: ["key_follow", "keytrk", "filter_key_follow"],
    attack: ["attack", "env_attack"],
    env_attack: ["attack", "env_attack"],
    decay: ["decay", "env_decay"],
    env_decay: ["decay", "env_decay"],
    sustain: ["sustain", "env_sustain"],
    env_sustain: ["sustain", "env_sustain"],
    release: ["release", "env_release"],
    env_release: ["release", "env_release"],
    env_trg: ["env_trg", "env_trig"],
    env_trig: ["env_trg", "env_trig"],
    range: ["range", "osc_range"],
    osc_range: ["range", "osc_range"],
    pulse_lvl: ["pulse_lvl", "osc_pulse_lvl"],
    osc_pulse_lvl: ["pulse_lvl", "osc_pulse_lvl"],
    saw_lvl: ["saw_lvl", "osc_saw_lvl"],
    osc_saw_lvl: ["saw_lvl", "osc_saw_lvl"],
    sub_lvl: ["sub_lvl", "osc_sub_lvl"],
    osc_sub_lvl: ["sub_lvl", "osc_sub_lvl"],
    sub_type: ["sub_type", "osc_sub_type"],
    osc_sub_type: ["sub_type", "osc_sub_type"],
    noise_lvl: ["noise_lvl", "osc_noise_lvl"],
    osc_noise_lvl: ["noise_lvl", "osc_noise_lvl"],
    noise_mode: ["noise_mode", "osc_noise_mode"],
    osc_noise_mode: ["noise_mode", "osc_noise_mode"],
    fine_tune: ["fine_tune", "osc_fine_tune"],
    osc_fine_tune: ["fine_tune", "osc_fine_tune"],
    draw_sw: ["draw_sw", "draw_switch"],
    draw_switch: ["draw_sw", "draw_switch"],
    chop_ovtn: ["chop_ovtn", "chop_overtone"],
    chop_overtone: ["chop_ovtn", "chop_overtone"],
    lfo_pitch: ["lfo_pitch", "lfo_pitch_depth"],
    lfo_pitch_depth: ["lfo_pitch", "lfo_pitch_depth"],
    dly_lvl: ["dly_lvl", "delay_lvl"],
    delay_lvl: ["dly_lvl", "delay_lvl"],
    dly_time: ["dly_time", "delay_time"],
    delay_time: ["dly_time", "delay_time"],
    dly_fb: ["dly_fb", "delay_fb"],
    delay_fb: ["dly_fb", "delay_fb"],
    dly_sync: ["dly_sync", "delay_sync"],
    delay_sync: ["dly_sync", "delay_sync"],
    rev_lvl: ["rev_lvl", "reverb_lvl"],
    reverb_lvl: ["rev_lvl", "reverb_lvl"],
    rev_time: ["rev_time", "reverb_time"],
    reverb_time: ["rev_time", "reverb_time"],
    rev_type: ["rev_type", "reverb_type"],
    reverb_type: ["rev_type", "reverb_type"],
    cho_mode: ["cho_mode", "chorus_mode"],
    chorus_mode: ["cho_mode", "chorus_mode"]
  };

  const P = (id) => {
    let p = vibe.byId(id);
    if (p) return p;
    const al = ALIASES[id];
    if (al) {
      for (const a of al) {
        p = vibe.byId(a);
        if (p) return p;
      }
    }
    return undefined;
  };
  const norm = (p, v) => (p && p.max > p.min ? (v - p.min) / (p.max - p.min) : 0);
  const plain = (p, n) => (p ? p.min + n * (p.max - p.min) : 0);
  const fmt = (p, v) => {
    if (p.unit === "st" || p.unit === "cents" || p.unit === "%") {
      return (v > 0 ? "+" : "") + Math.round(v) + (p.unit ? p.unit : "");
    }
    return (v >= 100 ? v.toFixed(0) : v >= 10 ? v.toFixed(1) : v.toFixed(2)) + (p.unit ? " " + p.unit : "");
  };

  /* -------------------------------------------------------------
   * 1. 7-Segment Display & Preset Selector
   * ------------------------------------------------------------- */
  const pPreset = P("preset");
  const selPreset = document.getElementById("sel-preset");
  const segDisp = document.getElementById("seg-disp");

  const FACTORY_NAMES = [];
  for (let b = 1; b <= 4; b++) {
    for (let s = 1; s <= 16; s++) {
      FACTORY_NAMES.push(`PTN ${b}-${s < 10 ? "0" : ""}${s}`);
    }
  }

  const getPresetName = (idx) => {
    if (pPreset && pPreset.choices && pPreset.choices[idx]) return pPreset.choices[idx];
    if (FACTORY_NAMES[idx]) return FACTORY_NAMES[idx];
    return `PATCH ${idx + 1}`;
  };

  const populatePresets = () => {
    if (!selPreset) return;
    selPreset.innerHTML = "";
    const count = (pPreset && pPreset.choices && pPreset.choices.length) ? pPreset.choices.length : 64;
    for (let i = 0; i < count; i++) {
      selPreset.add(new Option(getPresetName(i), i));
    }
  };
  populatePresets();

  const changePreset = (target) => {
    target = Math.max(0, Math.min(63, Math.round(target)));
    if (pPreset) {
      vibe.set(pPreset.i, target);
    }
    // Direct command fallback: Cmd 5 = direct patch change [5, target]
    vibe.send(new Uint8Array([5, target]));
    // Request updated draw table & chop mask for this preset
    vibe.send(new Uint8Array([2]));
    vibe.send(new Uint8Array([4]));
  };

  if (selPreset) {
    selPreset.addEventListener("change", () => {
      changePreset(parseInt(selPreset.value, 10));
    });
  }

  const btnPrev = document.getElementById("btn-prev-patch");
  if (btnPrev) {
    btnPrev.addEventListener("click", () => {
      const cur = pPreset ? Math.round(vibe.values[pPreset.i]) : (parseInt(selPreset.value, 10) || 0);
      changePreset(cur - 1);
    });
  }

  const btnNext = document.getElementById("btn-next-patch");
  if (btnNext) {
    btnNext.addEventListener("click", () => {
      const cur = pPreset ? Math.round(vibe.values[pPreset.i]) : (parseInt(selPreset.value, 10) || 0);
      changePreset(cur + 1);
    });
  }

  /* -------------------------------------------------------------
   * 1b. Key Transpose Quick Controls
   * ------------------------------------------------------------- */
  const pTransp = P("transpose");
  const stepTranspose = (delta) => {
    if (!pTransp) return;
    const cur = Math.round(vibe.values[pTransp.i]);
    const next = Math.min(pTransp.max, Math.max(pTransp.min, cur + delta));
    vibe.set(pTransp.i, next);
  };

  const btnTranspDown = document.getElementById("btn-transp-down");
  const btnTranspUp = document.getElementById("btn-transp-up");
  const btnTranspDownKb = document.getElementById("btn-transp-down-kb");
  const btnTranspUpKb = document.getElementById("btn-transp-up-kb");
  const valTranspHdr = document.getElementById("val-transpose-hdr");
  const valTranspKb = document.getElementById("val-transpose-kb");

  if (btnTranspDown) btnTranspDown.addEventListener("click", () => stepTranspose(-1));
  if (btnTranspUp) btnTranspUp.addEventListener("click", () => stepTranspose(1));
  if (btnTranspDownKb) btnTranspDownKb.addEventListener("click", () => stepTranspose(-1));
  if (btnTranspUpKb) btnTranspUpKb.addEventListener("click", () => stepTranspose(1));

  /* -------------------------------------------------------------
   * 2. Header Buttons: Transport, Reverb Eco & Template Helpers
   * ------------------------------------------------------------- */
  const T = window.VibeUITemplate;
  const lookup = { find: P, norm, fmt };

  const btnPlay = document.getElementById("btn-play");
  let isPlaying = false;
  if (btnPlay) {
    btnPlay.addEventListener("click", () => {
      const pSeq = P("seq_play");
      isPlaying = !isPlaying;
      if (pSeq) vibe.set(pSeq.i, isPlaying ? 1 : 0);
      btnPlay.classList.toggle("active", isPlaying);
      btnPlay.textContent = isPlaying ? "⏹ STOP" : "▶ PLAY";
    });
  }

  const btnRevEco = document.getElementById("btn-rev_eco");
  let revEco = false;
  if (btnRevEco) {
    btnRevEco.addEventListener("click", () => {
      revEco = !revEco;
      vibe.send(new Uint8Array([6, revEco ? 1 : 0]));
    });
  }

  /* -------------------------------------------------------------
   * 3. Rotary Knobs (via VibeUITemplate)
   * ------------------------------------------------------------- */
  const knobCtl = T.bindKnobs(vibe, lookup);

  /* -------------------------------------------------------------
   * 4. Select Dropdowns (via VibeUITemplate)
   * ------------------------------------------------------------- */
  const selCtl = T.bindSelects(vibe, lookup);

  /* -------------------------------------------------------------
   * 5. Toggle Switch Buttons (via VibeUITemplate)
   * ------------------------------------------------------------- */
  const togCtl = T.bindToggles(vibe, lookup, [
    { btnId: "btn-lfo_sync", paramId: "lfo_sync" },
    { btnId: "btn-dly_sync", paramId: "dly_sync" },
    { btnId: "btn-arp_on",   paramId: "arp_on" },
    { btnId: "btn-arp_hold", paramId: "arp_hold" }
  ]);

  /* -------------------------------------------------------------
   * 6. Live ST7789 240x240 LCD Canvas
   * ------------------------------------------------------------- */
  const lcdCanvas = document.getElementById("lcd-frame");
  if (lcdCanvas) {
    vibe.onFrame((fb) => vibe.paint(lcdCanvas, fb));
  }

  /* -------------------------------------------------------------
   * 7. Interactive Curves (Filter, Env, LFO via VibeUITemplate)
   * ------------------------------------------------------------- */
  function renderCurve(canvasId, cardName, strokeColor, fillColor) {
    return T.renderCurve(vibe, canvasId, cardName, strokeColor, fillColor);
  }

  /* -------------------------------------------------------------
   * 8. Interactive OSC DRAW (16-Step Wavetable Canvas)
   * ------------------------------------------------------------- */
  const drawCv = document.getElementById("draw-canvas");
  const drawCtx = drawCv ? drawCv.getContext("2d") : null;
  const drawTable = new Int8Array(16); // -100 to +100

  function paintDrawCanvas() {
    if (!drawCtx) return;
    const w = drawCv.width, h = drawCv.height;
    drawCtx.clearRect(0, 0, w, h);

    // Center baseline
    drawCtx.strokeStyle = "rgba(255, 255, 255, 0.15)";
    drawCtx.lineWidth = 1;
    drawCtx.beginPath();
    drawCtx.moveTo(0, h / 2);
    drawCtx.lineTo(w, h / 2);
    drawCtx.stroke();

    const barW = (w - 20) / 16;
    for (let i = 0; i < 16; i++) {
      const v = drawTable[i]; // -100..100
      const x = 10 + i * barW;
      const barH = (Math.abs(v) / 100) * (h / 2 - 4);
      const y = v >= 0 ? h / 2 - barH : h / 2;

      drawCtx.fillStyle = "rgba(0, 184, 135, 0.2)";
      drawCtx.fillRect(x + 2, 2, barW - 4, h - 4);

      drawCtx.fillStyle = v >= 0 ? "#00b887" : "#ff6b18";
      drawCtx.fillRect(x + 3, y, barW - 6, Math.max(2, barH));

      // Bar border
      drawCtx.strokeStyle = v >= 0 ? "#1cd69d" : "#ffa060";
      drawCtx.lineWidth = 1;
      drawCtx.strokeRect(x + 3, y, barW - 6, Math.max(2, barH));
    }
  }

  function handleDrawInput(e) {
    if (!drawCv) return;
    const r = drawCv.getBoundingClientRect();
    const clientX = Math.max(r.left, Math.min(r.right, e.clientX));
    const clientY = Math.max(r.top, Math.min(r.bottom, e.clientY));

    const step = Math.min(15, Math.max(0, Math.floor(((clientX - r.left) / r.width) * 16)));
    const relY = (clientY - r.top) / r.height; // 0 (top) to 1 (bottom)
    const amp = Math.round((0.5 - relY) * 200); // +100 to -100
    drawTable[step] = Math.max(-100, Math.min(100, amp));

    paintDrawCanvas();
    // Send Cmd 1 to firmware
    vibe.send(new Uint8Array([1, ...drawTable]));
  }

  if (drawCv) {
    drawCv.addEventListener("pointerdown", (e) => {
      drawCv.setPointerCapture(e.pointerId);
      handleDrawInput(e);
    });
    drawCv.addEventListener("pointermove", (e) => {
      if (e.buttons) handleDrawInput(e);
    });
  }

  document.getElementById("btn-draw-clear").addEventListener("click", () => {
    for (let i = 0; i < 16; i++) {
      drawTable[i] = Math.round(Math.sin((i / 16) * Math.PI * 2) * 90);
    }
    paintDrawCanvas();
    vibe.send(new Uint8Array([1, ...drawTable]));
  });

  /* -------------------------------------------------------------
   * 9. Interactive OSC CHOP (16-Step Mask Pads)
   * ------------------------------------------------------------- */
  const chopPadsBox = document.getElementById("chop-pads");
  const chopMasks = new Uint16Array([0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF]);
  let chopTarget = 0;

  for (let s = 0; s < 16; s++) {
    const pad = document.createElement("button");
    pad.className = "step-pad on";
    pad.textContent = s + 1;
    pad.addEventListener("click", () => {
      const bit = 1 << s;
      chopMasks[chopTarget] ^= bit;
      const mask = chopMasks[chopTarget];
      pad.classList.toggle("on", (mask & bit) !== 0);
      // Send Cmd 3 to firmware: [3, target, mask_lo, mask_hi]
      vibe.send(new Uint8Array([3, chopTarget, mask & 0xFF, (mask >> 8) & 0xFF]));
    });
    chopPadsBox.appendChild(pad);
  }

  function updateChopPadsDisplay() {
    const mask = chopMasks[chopTarget];
    const pads = chopPadsBox.querySelectorAll(".step-pad");
    pads.forEach((pad, s) => {
      pad.classList.toggle("on", (mask & (1 << s)) !== 0);
    });
  }

  const selChopTgt = document.getElementById("sel-chop_tgt");
  if (selChopTgt) {
    selChopTgt.innerHTML = "";
    ["SQR", "SAW", "SUB", "NOISE"].forEach((name, i) => selChopTgt.add(new Option(name, i)));
    selChopTgt.addEventListener("change", () => {
      chopTarget = parseInt(selChopTgt.value, 10) & 3;
      updateChopPadsDisplay();
    });
  }

  const selChopMask = document.getElementById("sel-chop_mask");
  if (selChopMask) {
    selChopMask.innerHTML = "";
    const PRESETS = [
      { name: "ALL ON", val: 0xFFFF },
      { name: "ALT 1",  val: 0x5555 },
      { name: "ALT 2",  val: 0xAAAA },
      { name: "BEAT 4", val: 0x8888 },
      { name: "HALF",   val: 0x00FF },
      { name: "INV H",  val: 0xFF00 },
      { name: "ALL OFF",val: 0x0000 }
    ];
    PRESETS.forEach((pr) => selChopMask.add(new Option(pr.name, pr.val)));
    selChopMask.addEventListener("change", () => {
      const val = parseInt(selChopMask.value, 10);
      chopMasks[chopTarget] = val;
      updateChopPadsDisplay();
      vibe.send(new Uint8Array([3, chopTarget, val & 0xFF, (val >> 8) & 0xFF]));
    });
  }

  /* -------------------------------------------------------------
   * 10. Patch, Sequence, MIDI Export & Bidirectional Data Handler
   * ------------------------------------------------------------- */
  const ioStatusEl = document.getElementById("io-status");
  const setIoStatus = (txt) => {
    if (ioStatusEl) ioStatusEl.textContent = txt;
  };

  const isTopWindow = (function () {
    try { return window.self === window.top; } catch (e) { return false; }
  })();

  function encodeSafeName(name) {
    const out = [];
    if (name) {
      for (let i = 0; i < name.length && i < 60; i++) {
        const ch = name.charCodeAt(i);
        out.push(ch >= 0x20 && ch < 0x7f ? ch : 0x5f);
      }
    }
    return out;
  }

  function sendCmdWithName(cmd, name) {
    const raw = encodeSafeName(name);
    const pkt = new Uint8Array(1 + raw.length);
    pkt[0] = cmd;
    pkt.set(raw, 1);
    vibe.send(pkt);
  }

  let pendingSeqAction = null; // "s1seq" | "mid" | null
  let pendingSaveTarget = null;
  let rxFileBuf = null;
  let fxUp = null;             // { cmd, bytes, total, nameBytes? }

  function pumpUpload(off) {
    if (!fxUp) return;
    if (off >= fxUp.total) {
      fxUp = null;
      return;
    }
    const chunk = Math.min(1024, fxUp.total - off);
    if (fxUp.cmd === 26) {
      const nb = (off === 0 && fxUp.nameBytes) ? fxUp.nameBytes : [];
      const pkt = new Uint8Array(6 + nb.length + chunk);
      pkt[0] = 26;
      pkt[1] = fxUp.nameBytes ? fxUp.nameBytes.length : 0;
      pkt[2] = fxUp.total & 0xFF;
      pkt[3] = (fxUp.total >> 8) & 0xFF;
      pkt[4] = off & 0xFF;
      pkt[5] = (off >> 8) & 0xFF;
      if (nb.length) pkt.set(nb, 6);
      pkt.set(fxUp.bytes.subarray(off, off + chunk), 6 + nb.length);
      vibe.send(pkt);
      return;
    }
    const pkt = new Uint8Array(5 + chunk);
    pkt[0] = fxUp.cmd;
    pkt[1] = fxUp.total & 0xFF;
    pkt[2] = (fxUp.total >> 8) & 0xFF;
    pkt[3] = off & 0xFF;
    pkt[4] = (off >> 8) & 0xFF;
    pkt.set(fxUp.bytes.subarray(off, off + chunk), 5);
    vibe.send(pkt);
  }

  function startMidiSaveUpload(name, bytes) {
    if (!bytes || bytes.length < 1 || bytes.length > 65535) {
      setIoStatus("MIDI: INVALID SIZE");
      return;
    }
    fxUp = { cmd: 26, bytes, total: bytes.length, nameBytes: encodeSafeName(name) };
    setIoStatus("SAVING MIDI...");
    pumpUpload(0);
  }

  function startChunkUpload(cmd, bytes, label) {
    if (!bytes || bytes.length < 60 || bytes.length > 65535) {
      setIoStatus("FILE: INVALID SIZE");
      return;
    }
    fxUp = { cmd, bytes, total: bytes.length };
    setIoStatus("UPLOADING " + label + "...");
    pumpUpload(0);
  }

  const wireClick = (id, fn) => {
    const el = document.getElementById(id);
    if (el) el.addEventListener("click", fn);
  };

  wireClick("btn-fxp-save", async () => {
    const curSlot = pPreset ? (Math.round(vibe.values[pPreset.i]) + 1) : 1;
    const defName = `s1vave_patch_${curSlot < 10 ? "0" : ""}${curSlot}.fxp`;
    const tgt = await T.promptSaveFile(defName, "S1Vave Patch (.fxp)", "application/octet-stream", ".fxp", "Music\\VIBE FM\\s1vave\\");
    if (!tgt) { setIoStatus("SAVE CANCELLED"); return; }
    pendingSaveTarget = tgt;
    setIoStatus("SAVING FXP...");
    sendCmdWithName(10, tgt.name);
  });
  wireClick("btn-fxb-save", async () => {
    const tgt = await T.promptSaveFile("s1vave_bank.fxb", "S1Vave Bank (.fxb)", "application/octet-stream", ".fxb", "Music\\VIBE FM\\s1vave\\");
    if (!tgt) { setIoStatus("SAVE CANCELLED"); return; }
    pendingSaveTarget = tgt;
    setIoStatus("SAVING FXB...");
    sendCmdWithName(11, tgt.name);
  });
  wireClick("btn-fm1-grab", () => vibe.send(new Uint8Array([12])));
  wireClick("btn-fm1-send", () => vibe.send(new Uint8Array([14])));
  wireClick("btn-seq-grab", () => vibe.send(new Uint8Array([23])));
  wireClick("btn-seq-send", () => vibe.send(new Uint8Array([24])));

  wireClick("btn-seq-save", async () => {
    const curSlot = pPreset ? (Math.round(vibe.values[pPreset.i]) + 1) : 1;
    const tgt = await T.promptSaveFile(`s1vave_ptn_${curSlot}.s1seq`, "S1Vave Sequence (.s1seq)", "application/octet-stream", ".s1seq", "Music\\VIBE FM\\s1vave\\");
    if (!tgt) { setIoStatus("SAVE CANCELLED"); return; }
    pendingSaveTarget = tgt;
    pendingSeqAction = (tgt.handle || isTopWindow) ? "s1seq" : null;
    setIoStatus("SAVING SEQUENCE...");
    sendCmdWithName(25, tgt.name);
  });

  wireClick("btn-midi-export", async () => {
    const curSlot = pPreset ? (Math.round(vibe.values[pPreset.i]) + 1) : 1;
    const tgt = await T.promptSaveFile(`s1vave_ptn_${curSlot}.mid`, "Standard MIDI File (.mid)", "audio/midi", ".mid", "Music\\VIBE FM\\s1vave\\");
    if (!tgt) { setIoStatus("SAVE CANCELLED"); return; }
    pendingSaveTarget = tgt;
    pendingSeqAction = "mid";
    setIoStatus("EXPORTING MIDI...");
    vibe.send(new Uint8Array([21]));
  });

  const fileFxInput = document.getElementById("file-fx-input");
  const fileSeqInput = document.getElementById("file-seq-input");
  wireClick("btn-fx-load", () => { if (fileFxInput) fileFxInput.click(); });
  wireClick("btn-seq-load", () => { if (fileSeqInput) fileSeqInput.click(); });

  const handleUploadedFile = (file, forceSeq) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const bytes = new Uint8Array(reader.result);
      const isS1Seq = forceSeq ||
        file.name.toLowerCase().endsWith(".s1seq") ||
        (bytes.length >= 4 && bytes[0] === 0x53 && bytes[1] === 0x56 && bytes[2] === 0x53 && bytes[3] === 0x31);
      startChunkUpload(isS1Seq ? 22 : 20, bytes, file.name.toUpperCase());
    };
    reader.readAsArrayBuffer(file);
  };

  if (fileFxInput) {
    fileFxInput.addEventListener("change", () => {
      handleUploadedFile(fileFxInput.files[0], false);
      fileFxInput.value = "";
    });
  }
  if (fileSeqInput) {
    fileSeqInput.addEventListener("change", () => {
      handleUploadedFile(fileSeqInput.files[0], true);
      fileSeqInput.value = "";
    });
  }

  vibe.onData(async (bytes) => {
    if (!bytes || bytes.length === 0) return;
    const cmd = bytes[0];

    // Cmd 2: Draw table from firmware [2, d0..d15]
    if (cmd === 2 && bytes.length >= 17) {
      for (let i = 0; i < 16; i++) {
        const raw = bytes[1 + i];
        drawTable[i] = raw >= 128 ? raw - 256 : raw;
      }
      paintDrawCanvas();
    } else if (cmd === 4 && bytes.length >= 9) {
      // Cmd 4: Chop masks from firmware [4, m0_lo, m0_hi, ...]
      for (let i = 0; i < 4; i++) {
        chopMasks[i] = bytes[1 + i * 2] | (bytes[2 + i * 2] << 8);
      }
      updateChopPadsDisplay();
    } else if (cmd === 5 && bytes.length >= 2) {
      const curProg = bytes[1];
      lastPreset = curProg;
      if (selPreset && document.activeElement !== selPreset) {
        selPreset.value = curProg;
      }
      if (segDisp) {
        const name = getPresetName(curProg);
        const numStr = (curProg + 1 < 10 ? "0" : "") + (curProg + 1);
        segDisp.textContent = `${numStr}: ${name.toUpperCase()}`;
      }
    } else if (cmd === 6 && bytes.length >= 2) {
      revEco = bytes[1] !== 0;
      if (btnRevEco) {
        btnRevEco.classList.toggle("active", revEco);
        btnRevEco.textContent = revEco ? "REV ECO: ECO" : "REV ECO: HQ";
      }
    } else if (cmd === 0x40 && bytes.length >= 2) {
      let msg = "";
      for (let i = 1; i < bytes.length; i++) {
        if (bytes[i] === 0) break;
        msg += String.fromCharCode(bytes[i]);
      }
      setIoStatus(msg);
    } else if ((cmd === 0x42 || cmd === 0x43 || cmd === 0x45) && bytes.length >= 3) {
      const off = bytes[1] | (bytes[2] << 8);
      pumpUpload(off);
    } else if (cmd === 0x44 && bytes.length >= 6) {
      const kind = bytes[1];
      const total = bytes[2] | (bytes[3] << 8);
      const off = bytes[4] | (bytes[5] << 8);
      const chunk = bytes.subarray(6);
      if (off === 0 || !rxFileBuf || rxFileBuf.length !== total) {
        rxFileBuf = new Uint8Array(total);
      }
      if (off + chunk.length <= total) {
        rxFileBuf.set(chunk, off);
      }
      if (off + chunk.length >= total) {
        const tgt = pendingSaveTarget || { handle: null, name: kind ? "s1vave_bank.fxb" : "s1vave_patch.fxp" };
        pendingSaveTarget = null;
        if (tgt.handle || isTopWindow) {
          try {
            const savedName = await T.finishSaveFile(tgt, rxFileBuf, "application/octet-stream");
            setIoStatus(`SAVED ${savedName.toUpperCase()}`);
          } catch (err) {
            setIoStatus("SAVE FAILED");
          }
        }
        rxFileBuf = null;
      }
    } else if (cmd === 21 && bytes.length >= 2118) {
      const slot = bytes[1];
      const patBytes = bytes.slice(2, 2118);
      setPatternBuffer(patBytes, slot);
      const pTempo = P("tempo");
      const fallbackBpm = pTempo ? Math.round(vibe.values[pTempo.i]) : 120;
      const tgt = pendingSaveTarget;
      const action = pendingSeqAction;
      pendingSaveTarget = null;
      pendingSeqAction = null;
      if (action) {
        try {
          if (action === "s1seq") {
            const target = tgt || { handle: null, name: `s1vave_ptn_${slot + 1}.s1seq` };
            if (target.handle || isTopWindow) {
              const savedName = await T.finishSaveFile(target, patBytes, "application/octet-stream");
              setIoStatus(`SAVED ${savedName.toUpperCase()}`);
            }
          } else if (action === "mid") {
            const midiBytes = T.patternToMidiBytes(patBytes, fallbackBpm);
            const target = tgt || { handle: null, name: `s1vave_ptn_${slot + 1}.mid` };
            if (target.handle || isTopWindow) {
              const savedName = await T.finishSaveFile(target, midiBytes, "audio/midi");
              setIoStatus(`EXPORTED ${savedName.toUpperCase()}`);
            } else {
              startMidiSaveUpload(target.name, midiBytes);
            }
          }
        } catch (err) {
          setIoStatus("SAVE FAILED");
        }
      }
    } else if (cmd === 31 && bytes.length >= 7) {
      const slot = bytes[1];
      const posA = bytes[2] | (bytes[3] << 8);
      const posB = bytes[4] | (bytes[5] << 8);
      const running = bytes[6] !== 0;
      updateSeqPlayhead(posA, posB, running);
      if (slot !== currentPatSlot && !seqSlotFetchPending) {
        seqSlotFetchPending = true;
        vibe.send(new Uint8Array([21]));
      }
    }
  });

  /* -------------------------------------------------------------
   * 10B. Interactive Step Sequencer Editor & Direct MIDI Drag
   * ------------------------------------------------------------- */
  const SEQ_STEPS = 256;
  const STEP_OFF = 0x80;
  const GATE_TIE = 127;
  const NOTE_NAMES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"];

  function fmtNote(n) {
    if (!n || n <= 0) return "--";
    return NOTE_NAMES[n % 12] + (Math.floor(n / 12) - 1);
  }

  let currentPatSlot = 0;
  let seqSlotFetchPending = false;
  let seqTrk = 0;
  let seqBar = 0;
  let seqSelStep = 0;
  let seqKeyEntry = false;
  let seqAutoAdv = true;
  let seqPlayPos = [0, 0];
  let seqPlayRun = false;
  let lastPhPoll = 0;

  const currentPatBytes = new Uint8Array(2116);
  const patDv = new DataView(currentPatBytes.buffer);
  (function initDefaultPat() {
    patDv.setUint32(0, 0x31535653, true); // SVS1
    patDv.setUint16(4, 16, true); currentPatBytes[6] = 2; currentPatBytes[7] = 50;
    patDv.setUint16(12, 0, true); currentPatBytes[14] = 2; currentPatBytes[15] = 50;
    for (let i = 0; i < SEQ_STEPS; i++) {
      const off = 20 + i * 8;
      currentPatBytes[off + 4] = 100;
      currentPatBytes[off + 5] = 96;
      currentPatBytes[off + 6] = 0;
      currentPatBytes[off + 7] = 100;
    }
    currentPatBytes[2111] = 120;
  })();

  function setPatternBuffer(patBytes, slot) {
    if (patBytes && patBytes.length >= 2116) {
      currentPatBytes.set(patBytes.subarray(0, 2116), 0);
    }
    if (typeof slot === "number") currentPatSlot = slot & 7;
    seqSlotFetchPending = false;
    renderSeqUI();
  }

  function getTrk(t) {
    const off = 4 + t * 8;
    return {
      len: patDv.getUint16(off, true),
      div: currentPatBytes[off + 2] % 6,
      swing: Math.max(50, Math.min(75, currentPatBytes[off + 3] || 50)),
      transp: patDv.getInt8(off + 4),
      mute: currentPatBytes[off + 5] !== 0
    };
  }

  function sendTrackUpdate(t) {
    const tr = getTrk(t);
    vibe.send(new Uint8Array([
      28, t & 1, tr.len & 0xFF, (tr.len >> 8) & 0xFF,
      tr.div & 0xFF, tr.swing & 0xFF, tr.transp & 0xFF, tr.mute ? 1 : 0
    ]));
  }

  function stepOff(t, idx) {
    const slot = t ? (SEQ_STEPS - 1 - idx) : idx;
    return 20 + slot * 8;
  }

  function getStep(t, idx) {
    const o = stepOff(t, idx);
    return {
      notes: [currentPatBytes[o], currentPatBytes[o + 1], currentPatBytes[o + 2], currentPatBytes[o + 3]],
      vel: currentPatBytes[o + 4] || 100,
      gate: currentPatBytes[o + 5] || 96,
      ratch: currentPatBytes[o + 6],
      chance: currentPatBytes[o + 7]
    };
  }

  function writeStep(t, idx, st) {
    const o = stepOff(t, idx);
    for (let k = 0; k < 4; k++) currentPatBytes[o + k] = st.notes[k] || 0;
    currentPatBytes[o + 4] = Math.max(1, Math.min(127, st.vel || 100));
    currentPatBytes[o + 5] = Math.max(1, Math.min(127, st.gate || 96));
    currentPatBytes[o + 6] = st.ratch & 0x83;
    currentPatBytes[o + 7] = Math.max(0, Math.min(100, st.chance == null ? 100 : st.chance));
    vibe.send(new Uint8Array([
      27, t & 1, idx & 0xFF, (idx >> 8) & 0xFF,
      currentPatBytes[o], currentPatBytes[o + 1], currentPatBytes[o + 2], currentPatBytes[o + 3],
      currentPatBytes[o + 4], currentPatBytes[o + 5], currentPatBytes[o + 6], currentPatBytes[o + 7]
    ]));
  }

  const elSeqSlot = document.getElementById("seq-pat-slot");
  const elSeqTrkA = document.getElementById("seq-trk-a");
  const elSeqTrkB = document.getElementById("seq-trk-b");
  const elSeqMute = document.getElementById("seq-trk-mute");
  const elSeqLen = document.getElementById("seq-trk-len");
  const elSeqDiv = document.getElementById("seq-trk-div");
  const elSeqSwing = document.getElementById("seq-trk-swing");
  const elSeqTransp = document.getElementById("seq-trk-transp");
  const elSeqGrid = document.getElementById("seq-grid");
  const elStBadge = document.getElementById("seq-st-badge");
  const elStOn = document.getElementById("seq-st-on");
  const elStNote = document.getElementById("seq-st-note");
  const elStChord = document.getElementById("seq-st-chord");
  const elStVel = document.getElementById("seq-st-vel");
  const elStVelVal = document.getElementById("seq-st-vel-val");
  const elStGate = document.getElementById("seq-st-gate");
  const elStGateVal = document.getElementById("seq-st-gate-val");
  const elStTie = document.getElementById("seq-st-tie");
  const elStRatch = document.getElementById("seq-st-ratch");
  const elStChance = document.getElementById("seq-st-chance");
  const elStChanceVal = document.getElementById("seq-st-chance-val");
  const elKeyEntry = document.getElementById("seq-key-entry");
  const elKbSeqRec = document.getElementById("btn-kb-seq-rec");
  const elAutoAdv = document.getElementById("seq-auto-adv");

  if (elSeqSlot) {
    for (let i = 0; i < 8; i++) {
      const opt = document.createElement("option");
      opt.value = i;
      opt.textContent = "PTN " + (i + 1);
      elSeqSlot.appendChild(opt);
    }
    elSeqSlot.addEventListener("change", () => {
      const s = Math.max(0, Math.min(7, parseInt(elSeqSlot.value, 10) || 0));
      vibe.send(new Uint8Array([30, s]));
    });
  }

  if (elStNote) {
    const restOpt = document.createElement("option");
    restOpt.value = "0";
    restOpt.textContent = "---";
    elStNote.appendChild(restOpt);
    for (let n = 12; n <= 120; n++) {
      const opt = document.createElement("option");
      opt.value = String(n);
      opt.textContent = fmtNote(n);
      elStNote.appendChild(opt);
    }
  }

  const seqCellEls = [];
  if (elSeqGrid) {
    for (let i = 0; i < 16; i++) {
      const cell = document.createElement("div");
      cell.className = "seq-cell";
      cell.innerHTML =
        `<div class="seq-cell-top"><span class="seq-cell-num">${i + 1}</span><span class="seq-cell-dot" title="Toggle step ON/OFF"></span></div>` +
        `<div class="seq-cell-note">--</div>` +
        `<div class="seq-cell-sub"></div>` +
        `<div class="seq-cell-vel"><div class="seq-cell-vel-fill" style="width:0%"></div></div>`;
      const dot = cell.querySelector(".seq-cell-dot");
      dot.addEventListener("click", (e) => {
        e.stopPropagation();
        toggleStepActive(seqBar * 16 + i);
      });
      cell.addEventListener("click", () => {
        seqSelStep = seqBar * 16 + i;
        renderSeqUI();
      });
      cell.addEventListener("dblclick", () => {
        toggleStepActive(seqBar * 16 + i);
      });
      cell.addEventListener("contextmenu", (e) => {
        e.preventDefault();
        toggleStepActive(seqBar * 16 + i);
      });
      elSeqGrid.appendChild(cell);
      seqCellEls.push(cell);
    }
  }

  function ensureTrackHasLen(minLen) {
    const off = 4 + seqTrk * 8;
    const cur = patDv.getUint16(off, true);
    if (cur < minLen) {
      const next = Math.min(64, Math.max(16, minLen));
      patDv.setUint16(off, next, true);
      sendTrackUpdate(seqTrk);
    }
  }

  function toggleStepActive(idx) {
    seqSelStep = idx;
    const st = getStep(seqTrk, idx);
    if (!st.notes[0]) {
      st.notes = [60, 0, 0, 0];
      st.vel = st.vel || 100;
      st.gate = st.gate || 96;
      st.ratch &= ~STEP_OFF;
      ensureTrackHasLen(idx + 1);
    } else {
      st.ratch ^= STEP_OFF;
      if (!(st.ratch & STEP_OFF)) ensureTrackHasLen(idx + 1);
    }
    writeStep(seqTrk, idx, st);
    renderSeqUI();
  }

  function renderStepInspector() {
    const st = getStep(seqTrk, seqSelStep);
    const isOff = (st.ratch & STEP_OFF) !== 0;
    const active = st.notes[0] > 0 && !isOff;
    if (elStBadge) elStBadge.textContent = `TRK ${seqTrk ? "B" : "A"} · STP ${seqSelStep + 1}`;
    if (elStOn) {
      elStOn.textContent = active ? "ON" : "OFF";
      elStOn.classList.toggle("active", active);
    }
    if (elStNote && document.activeElement !== elStNote) {
      elStNote.value = String(st.notes[0] || 0);
    }
    if (elStChord) {
      const ch = st.notes.filter((x) => x > 0).map(fmtNote);
      elStChord.textContent = ch.length ? ch.join(" ") : "REST";
    }
    if (elStVel) elStVel.value = String(st.vel);
    if (elStVelVal) elStVelVal.textContent = String(st.vel);
    if (elStGate) elStGate.value = String(st.gate);
    if (elStGateVal) elStGateVal.textContent = st.gate >= GATE_TIE ? "TIE" : `${Math.round((st.gate * 100) / 127)}%`;
    if (elStTie) elStTie.classList.toggle("active", st.gate >= GATE_TIE);
    if (elStRatch && document.activeElement !== elStRatch) elStRatch.value = String(st.ratch & 3);
    if (elStChance) elStChance.value = String(st.chance);
    if (elStChanceVal) elStChanceVal.textContent = `${st.chance}%`;
  }

  function updateSeqPlayhead(posA, posB, running) {
    seqPlayPos[0] = posA;
    seqPlayPos[1] = posB;
    seqPlayRun = running;
    const tr = getTrk(seqTrk);
    const activePlay = (running && tr.len > 0) ? (seqPlayPos[seqTrk] % tr.len) : -1;
    for (let i = 0; i < 16; i++) {
      const idx = seqBar * 16 + i;
      if (seqCellEls[i]) seqCellEls[i].classList.toggle("playing", idx === activePlay);
    }
  }

  function renderSeqUI() {
    const tr = getTrk(seqTrk);
    if (elSeqSlot && document.activeElement !== elSeqSlot) elSeqSlot.value = String(currentPatSlot);
    if (elSeqTrkA) elSeqTrkA.classList.toggle("active", seqTrk === 0);
    if (elSeqTrkB) elSeqTrkB.classList.toggle("active", seqTrk === 1);
    if (elSeqMute) elSeqMute.classList.toggle("active", tr.mute);
    if (elSeqLen && document.activeElement !== elSeqLen) elSeqLen.value = String(tr.len);
    if (elSeqDiv && document.activeElement !== elSeqDiv) elSeqDiv.value = String(tr.div);
    if (elSeqSwing && document.activeElement !== elSeqSwing) elSeqSwing.value = String(tr.swing);
    if (elSeqTransp && document.activeElement !== elSeqTransp) elSeqTransp.value = String(tr.transp);

    for (let b = 0; b < 4; b++) {
      const btn = document.getElementById("seq-bar-" + b);
      if (btn) btn.classList.toggle("active", seqBar === b);
    }

    const activePlay = (seqPlayRun && tr.len > 0) ? (seqPlayPos[seqTrk] % tr.len) : -1;
    for (let i = 0; i < 16; i++) {
      const cell = seqCellEls[i];
      if (!cell) continue;
      const idx = seqBar * 16 + i;
      const st = getStep(seqTrk, idx);
      const hasNote = st.notes[0] > 0 && !(st.ratch & STEP_OFF);
      const inBounds = idx < tr.len;
      const extraNotes = st.notes.filter((x) => x > 0).length - 1;
      cell.classList.toggle("active", hasNote);
      cell.classList.toggle("selected", idx === seqSelStep);
      cell.classList.toggle("playing", idx === activePlay);
      cell.classList.toggle("muted", st.notes[0] > 0 && (st.ratch & STEP_OFF) !== 0);
      cell.classList.toggle("oob", !inBounds);
      cell.querySelector(".seq-cell-num").textContent = String(idx + 1);
      cell.querySelector(".seq-cell-note").textContent = st.notes[0] ? (fmtNote(st.notes[0]) + (extraNotes > 0 ? `+${extraNotes}` : "")) : "--";
      let badges = [];
      if (st.gate >= GATE_TIE) badges.push("TIE");
      if ((st.ratch & 3) > 0) badges.push(((st.ratch & 3) + 1) + "x");
      if (st.chance < 100) badges.push(st.chance + "%");
      cell.querySelector(".seq-cell-sub").textContent = badges.join(" ");
      cell.querySelector(".seq-cell-vel-fill").style.width = hasNote ? `${Math.round((st.vel / 127) * 100)}%` : "0%";
    }
    renderStepInspector();
  }

  wireClick("seq-trk-a", () => { seqTrk = 0; renderSeqUI(); });
  wireClick("seq-trk-b", () => { seqTrk = 1; renderSeqUI(); });
  wireClick("seq-trk-mute", () => {
    const off = 4 + seqTrk * 8;
    currentPatBytes[off + 5] = currentPatBytes[off + 5] ? 0 : 1;
    sendTrackUpdate(seqTrk);
    renderSeqUI();
  });
  for (let b = 0; b < 4; b++) {
    wireClick("seq-bar-" + b, () => {
      seqBar = b;
      seqSelStep = b * 16 + (seqSelStep % 16);
      renderSeqUI();
    });
  }
  if (elSeqLen) elSeqLen.addEventListener("change", () => {
    const val = Math.max(0, Math.min(64, parseInt(elSeqLen.value, 10) || 0));
    patDv.setUint16(4 + seqTrk * 8, val, true);
    sendTrackUpdate(seqTrk);
    renderSeqUI();
  });
  if (elSeqDiv) elSeqDiv.addEventListener("change", () => {
    currentPatBytes[4 + seqTrk * 8 + 2] = Math.max(0, Math.min(5, parseInt(elSeqDiv.value, 10) || 0));
    sendTrackUpdate(seqTrk);
    renderSeqUI();
  });
  if (elSeqSwing) elSeqSwing.addEventListener("change", () => {
    currentPatBytes[4 + seqTrk * 8 + 3] = Math.max(50, Math.min(75, parseInt(elSeqSwing.value, 10) || 50));
    sendTrackUpdate(seqTrk);
  });
  if (elSeqTransp) elSeqTransp.addEventListener("change", () => {
    patDv.setInt8(4 + seqTrk * 8 + 4, Math.max(-24, Math.min(24, parseInt(elSeqTransp.value, 10) || 0)));
    sendTrackUpdate(seqTrk);
  });
  function syncKeyRecUI() {
    if (elKeyEntry) {
      elKeyEntry.classList.toggle("active", seqKeyEntry);
      elKeyEntry.textContent = seqKeyEntry ? "● KEY REC: ON" : "● KEY REC: OFF";
    }
    if (elKbSeqRec) {
      elKbSeqRec.classList.toggle("active", seqKeyEntry);
      elKbSeqRec.textContent = seqKeyEntry ? "● SEQ REC: ON" : "● SEQ REC: OFF";
    }
    if (elAutoAdv) {
      elAutoAdv.classList.toggle("active", seqAutoAdv);
      elAutoAdv.style.opacity = seqKeyEntry ? "1" : "0.45";
    }
  }
  const toggleKeyRec = () => {
    seqKeyEntry = !seqKeyEntry;
    syncKeyRecUI();
  };
  wireClick("seq-key-entry", toggleKeyRec);
  wireClick("btn-kb-seq-rec", toggleKeyRec);
  wireClick("seq-auto-adv", () => {
    seqAutoAdv = !seqAutoAdv;
    syncKeyRecUI();
  });
  syncKeyRecUI();
  wireClick("seq-clear-trk", () => {
    vibe.send(new Uint8Array([29, seqTrk]));
  });
  wireClick("seq-clear-ptn", () => {
    vibe.send(new Uint8Array([29, 2]));
  });

  wireClick("seq-st-on", () => toggleStepActive(seqSelStep));
  if (elStNote) elStNote.addEventListener("change", () => {
    const n = Math.max(0, Math.min(127, parseInt(elStNote.value, 10) || 0));
    const st = getStep(seqTrk, seqSelStep);
    if (n === 0) {
      st.notes = [0, 0, 0, 0];
    } else {
      st.notes[0] = n;
      st.ratch &= ~STEP_OFF;
      ensureTrackHasLen(seqSelStep + 1);
    }
    writeStep(seqTrk, seqSelStep, st);
    renderSeqUI();
  });

  function shiftStepNote(delta) {
    const st = getStep(seqTrk, seqSelStep);
    if (!st.notes[0]) st.notes[0] = 60;
    else st.notes[0] = Math.max(12, Math.min(120, st.notes[0] + delta));
    st.ratch &= ~STEP_OFF;
    ensureTrackHasLen(seqSelStep + 1);
    writeStep(seqTrk, seqSelStep, st);
    renderSeqUI();
  }
  wireClick("seq-st-oct-dn", () => shiftStepNote(-12));
  wireClick("seq-st-semi-dn", () => shiftStepNote(-1));
  wireClick("seq-st-semi-up", () => shiftStepNote(1));
  wireClick("seq-st-oct-up", () => shiftStepNote(12));

  if (elStVel) elStVel.addEventListener("input", () => {
    const st = getStep(seqTrk, seqSelStep);
    st.vel = Math.max(1, Math.min(127, parseInt(elStVel.value, 10) || 100));
    writeStep(seqTrk, seqSelStep, st);
    renderSeqUI();
  });
  if (elStGate) elStGate.addEventListener("input", () => {
    const st = getStep(seqTrk, seqSelStep);
    st.gate = Math.max(1, Math.min(127, parseInt(elStGate.value, 10) || 96));
    writeStep(seqTrk, seqSelStep, st);
    renderSeqUI();
  });
  wireClick("seq-st-tie", () => {
    const st = getStep(seqTrk, seqSelStep);
    st.gate = (st.gate >= GATE_TIE) ? 96 : GATE_TIE;
    writeStep(seqTrk, seqSelStep, st);
    renderSeqUI();
  });
  if (elStRatch) elStRatch.addEventListener("change", () => {
    const st = getStep(seqTrk, seqSelStep);
    st.ratch = (st.ratch & STEP_OFF) | (parseInt(elStRatch.value, 10) & 3);
    writeStep(seqTrk, seqSelStep, st);
    renderSeqUI();
  });
  if (elStChance) elStChance.addEventListener("input", () => {
    const st = getStep(seqTrk, seqSelStep);
    st.chance = Math.max(0, Math.min(100, parseInt(elStChance.value, 10) || 0));
    writeStep(seqTrk, seqSelStep, st);
    renderSeqUI();
  });
  wireClick("seq-st-clear", () => {
    writeStep(seqTrk, seqSelStep, { notes: [0, 0, 0, 0], vel: 100, gate: 96, ratch: 0, chance: 100 });
    renderSeqUI();
  });

  renderSeqUI();

  // Request initial draw table, chop masks, Reverb Eco, and live pattern from firmware
  vibe.send(new Uint8Array([2]));
  vibe.send(new Uint8Array([4]));
  vibe.send(new Uint8Array([6]));
  vibe.send(new Uint8Array([21]));

  /* -------------------------------------------------------------
   * 11. Playable Keyboard (C2 to C4 via VibeUITemplate)
   * ------------------------------------------------------------- */
  T.buildKeyboard(document.getElementById("keys"), (n, vel) => {
    vibe.note(n, vel);
    if (vel > 0 && seqKeyEntry) {
      const st = getStep(seqTrk, seqSelStep);
      st.notes = [n, 0, 0, 0];
      st.vel = Math.max(40, Math.min(127, Math.round(vel)));
      st.gate = st.gate || 96;
      st.ratch &= ~STEP_OFF;
      ensureTrackHasLen(seqSelStep + 1);
      writeStep(seqTrk, seqSelStep, st);
      if (seqAutoAdv) {
        const len = Math.max(1, getTrk(seqTrk).len || 16);
        seqSelStep = (seqSelStep + 1) % len;
        seqBar = Math.floor(seqSelStep / 16);
      }
      renderSeqUI();
    }
  }, 36, 25);

  /* -------------------------------------------------------------
   * 12. Main Update Loop (vibe.onValues)
   * ------------------------------------------------------------- */
  let curveBusy = false;
  let lastPreset = -1;

  vibe.onValues(async (values) => {
    knobCtl.update(values);
    selCtl.update(values);
    togCtl.update(values);

    // Update Transport Play Button
    const pSeq = P("seq_play");
    if (pSeq && btnPlay) {
      const v = Math.round(values[pSeq.i]);
      isPlaying = v !== 0;
      btnPlay.classList.toggle("active", isPlaying);
      btnPlay.textContent = isPlaying ? "⏹ STOP" : "▶ PLAY";
    }

    const nowMs = performance.now();
    if ((isPlaying || seqPlayRun) && nowMs - lastPhPoll > 110) {
      lastPhPoll = nowMs;
      vibe.send(new Uint8Array([31]));
    }

    // 4. Update Preset & 7-Segment display
    if (pPreset) {
      const curProg = Math.round(values[pPreset.i]);
      if (selPreset && document.activeElement !== selPreset && selPreset.value != curProg) {
        selPreset.value = curProg;
      }
      if (curProg !== lastPreset) {
        lastPreset = curProg;
        const name = getPresetName(curProg);
        if (segDisp) {
          const numStr = (curProg + 1 < 10 ? "0" : "") + (curProg + 1);
          segDisp.textContent = `${numStr}: ${name.toUpperCase()}`;
        }
        // Request updated draw table & chop mask for this preset
        vibe.send(new Uint8Array([2]));
        vibe.send(new Uint8Array([4]));
      }
    }

    // 5. Update Transpose Quick Displays
    if (pTransp) {
      const v = Math.round(values[pTransp.i]);
      const txt = (v > 0 ? "+" : "") + v + " ST";
      if (valTranspHdr) valTranspHdr.textContent = txt;
      if (valTranspKb) valTranspKb.textContent = txt;
    }

    // 6. Update Curves
    if (!curveBusy) {
      curveBusy = true;
      try {
        await renderCurve("flt-curve", "FILTER", "#ff6b18", "rgba(255, 107, 24, 0.15)");
        await renderCurve("env-curve", "ENVELOPE", "#00b887", "rgba(0, 184, 135, 0.15)");
        await renderCurve("lfo-curve", "LFO", "#3fa9f5", "rgba(63, 169, 245, 0.15)");
      } catch (err) {
        // Curve rendering ignore
      }
      curveBusy = false;
    }
  });

  paintDrawCanvas();
})();

