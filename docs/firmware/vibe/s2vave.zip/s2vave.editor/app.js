// SPDX-License-Identifier: GPL-3.0-only
// S2Vave / Roland S-1 Clone Official Editor Engine (SDK 16)

(async () => {
  await vibe.ready;

  const P = (id) => vibe.byId(id);
  const norm = (p, v) => (p && p.max > p.min ? (v - p.min) / (p.max - p.min) : 0);
  const plain = (p, n) => (p ? p.min + n * (p.max - p.min) : 0);
  const fmt = (p, v) => {
    if (p.unit === "st" || p.unit === "cents" || p.unit === "%") {
      return (v > 0 ? "+" : "") + Math.round(v) + (p.unit ? p.unit : "");
    }
    return (v >= 100 ? v.toFixed(0) : v >= 10 ? v.toFixed(1) : v.toFixed(2)) + (p.unit ? " " + p.unit : "");
  };

  /* -------------------------------------------------------------
   * 1. 7-Segment Display & Preset Selector
   * ------------------------------------------------------------- */
  const pPreset = P("preset");
  const selPreset = document.getElementById("sel-preset");
  const segDisp = document.getElementById("seg-disp");

  if (pPreset && pPreset.choices) {
    pPreset.choices.forEach((name, i) => {
      selPreset.add(new Option(name, i));
    });
    selPreset.addEventListener("change", () => {
      vibe.set(pPreset.i, parseInt(selPreset.value, 10));
    });
  }

  document.getElementById("btn-prev-patch").addEventListener("click", () => {
    if (!pPreset) return;
    const cur = Math.round(vibe.values[pPreset.i]);
    const next = Math.max(pPreset.min, cur - 1);
    vibe.set(pPreset.i, next);
  });

  document.getElementById("btn-next-patch").addEventListener("click", () => {
    if (!pPreset) return;
    const cur = Math.round(vibe.values[pPreset.i]);
    const next = Math.min(pPreset.max, cur + 1);
    vibe.set(pPreset.i, next);
  });

  /* -------------------------------------------------------------
   * 1b. Key Transpose Quick Controls (custom steppers)
   * ------------------------------------------------------------- */
  const pTransp = P("transpose");
  const stepTranspose = (delta) => {
    if (!pTransp) return;
    const cur = Math.round(vibe.values[pTransp.i]);
    const next = Math.min(pTransp.max, Math.max(pTransp.min, cur + delta));
    vibe.set(pTransp.i, next);
  };

  const btnTranspDown = document.getElementById("btn-transp-down");
  const btnTranspUp = document.getElementById("btn-transp-up");
  const btnTranspDownKb = document.getElementById("btn-transp-down-kb");
  const btnTranspUpKb = document.getElementById("btn-transp-up-kb");
  const valTranspHdr = document.getElementById("val-transpose-hdr");
  const valTranspKb = document.getElementById("val-transpose-kb");

  if (btnTranspDown) btnTranspDown.addEventListener("click", () => stepTranspose(-1));
  if (btnTranspUp) btnTranspUp.addEventListener("click", () => stepTranspose(1));
  if (btnTranspDownKb) btnTranspDownKb.addEventListener("click", () => stepTranspose(-1));
  if (btnTranspUpKb) btnTranspUpKb.addEventListener("click", () => stepTranspose(1));
  /* -------------------------------------------------------------
   * 2. Header Buttons: Transport & HQ
   * ------------------------------------------------------------- */
  const btnPlay = document.getElementById("btn-play");
  let isPlaying = false;
  btnPlay.addEventListener("click", () => {
    const pSeq = P("seq_play");
    isPlaying = !isPlaying;
    if (pSeq) vibe.set(pSeq.i, isPlaying ? 1 : 0);
    btnPlay.classList.toggle("active", isPlaying);
    btnPlay.textContent = isPlaying ? "⏹ STOP" : "▶ PLAY";
  });

  const btnHq = document.getElementById("btn-hq");
  const pHq = P("hq_mode");
  btnHq.addEventListener("click", () => {
    if (!pHq) return;
    const cur = Math.round(vibe.values[pHq.i]);
    const next = cur ? 0 : 1;
    vibe.set(pHq.i, next);
  });

  /* -------------------------------------------------------------
   * 3. Rotary Knobs
   * ------------------------------------------------------------- */
  const knobElements = document.querySelectorAll(".knob");
  const knobs = [];

  knobElements.forEach((el) => {
    const id = el.dataset.id;
    const p = P(id);
    if (!p) return;

    let y0 = 0, v0 = 0;
    const valDisplay = document.getElementById("val-" + id);

    el.addEventListener("pointerdown", (e) => {
      el.setPointerCapture(e.pointerId);
      y0 = e.clientY;
      v0 = vibe.values[p.i];
    });

    el.addEventListener("pointermove", (e) => {
      if (!e.buttons) return;
      const fine = e.shiftKey ? 0.2 : 1.0;
      const range = p.max - p.min;
      const delta = ((y0 - e.clientY) / 150) * fine * range;
      const newVal = Math.min(p.max, Math.max(p.min, v0 + delta));
      vibe.set(p.i, newVal);
    });

    el.addEventListener("dblclick", () => {
      vibe.set(p.i, p.def);
    });

    el.addEventListener("wheel", (e) => {
      e.preventDefault();
      const step = (p.steps > 1 ? (p.max - p.min) / (p.steps - 1) : 1);
      const delta = (e.deltaY < 0 ? 1 : -1) * (e.shiftKey ? step * 0.2 : step);
      const cur = vibe.values[p.i];
      const newVal = Math.min(p.max, Math.max(p.min, cur + delta));
      vibe.set(p.i, newVal);
    }, { passive: false });

    knobs.push({ el, p, valDisplay });
  });

  /* -------------------------------------------------------------
   * 4. Select Dropdowns
   * ------------------------------------------------------------- */
  const selectElements = document.querySelectorAll("select[data-id]");
  const selects = [];

  selectElements.forEach((sel) => {
    const id = sel.dataset.id;
    const p = P(id);
    if (!p) return;

    if (p.choices && p.choices.length > 0) {
      sel.innerHTML = "";
      p.choices.forEach((name, idx) => {
        sel.add(new Option(name, idx));
      });
    }

    sel.addEventListener("change", () => {
      if (p.choices && p.choices.length > 0) {
        const stepVal = p.min + (parseInt(sel.value, 10) / (p.choices.length - 1)) * (p.max - p.min);
        vibe.set(p.i, stepVal);
      } else {
        vibe.set(p.i, parseFloat(sel.value));
      }
    });

    selects.push({ sel, p });
  });

  /* -------------------------------------------------------------
   * 5. Toggle Switch Buttons
   * ------------------------------------------------------------- */
  const toggleButtons = [
    { btnId: "btn-osc_sync", paramId: "osc_sync" },
    { btnId: "btn-lfo_sync", paramId: "lfo_sync" },
    { btnId: "btn-dly_sync", paramId: "dly_sync" },
    { btnId: "btn-arp_on",   paramId: "arp_on" },
    { btnId: "btn-arp_hold", paramId: "arp_hold" }
  ];

  const toggles = [];
  toggleButtons.forEach(({ btnId, paramId }) => {
    const btn = document.getElementById(btnId);
    const p = P(paramId);
    if (!btn || !p) return;

    btn.addEventListener("click", () => {
      const cur = Math.round(vibe.values[p.i]);
      vibe.set(p.i, cur ? 0 : 1);
    });

    toggles.push({ btn, p });
  });

  /* -------------------------------------------------------------
   * 6. Live ST7789 240x240 LCD Canvas
   * ------------------------------------------------------------- */
  const lcdCanvas = document.getElementById("lcd-frame");
  if (lcdCanvas) {
    vibe.onFrame((fb) => vibe.paint(lcdCanvas, fb));
  }

  /* -------------------------------------------------------------
   * 7. Interactive Curves (Filter, Env, LFO)
   * ------------------------------------------------------------- */
  async function renderCurve(canvasId, cardName, strokeColor, fillColor) {
    const cv = document.getElementById(canvasId);
    if (!cv) return;
    const g = cv.getContext("2d");
    const pts = await vibe.curve(cardName);
    if (!pts || !pts.length) return;

    const w = cv.width, h = cv.height;
    g.clearRect(0, 0, w, h);

    // Background grid
    g.strokeStyle = "rgba(255, 255, 255, 0.05)";
    g.lineWidth = 1;
    g.beginPath();
    g.moveTo(0, h * 0.5); g.lineTo(w, h * 0.5);
    g.moveTo(w * 0.5, 0); g.lineTo(w * 0.5, h);
    g.stroke();

    // Curve line
    g.beginPath();
    pts.forEach((y, k) => {
      const x = (k / (pts.length - 1)) * w;
      const cy = (1 - Math.max(0, Math.min(1, y))) * (h - 4) + 2;
      if (k === 0) g.moveTo(x, cy);
      else g.lineTo(x, cy);
    });

    if (fillColor) {
      g.lineTo(w, h);
      g.lineTo(0, h);
      g.closePath();
      g.fillStyle = fillColor;
      g.fill();
    }

    g.strokeStyle = strokeColor;
    g.lineWidth = 2;
    g.stroke();
  }

  /* -------------------------------------------------------------
   * 8. Interactive OSC DRAW (16-Step Wavetable Canvas)
   * ------------------------------------------------------------- */
  const drawCv = document.getElementById("draw-canvas");
  const drawCtx = drawCv ? drawCv.getContext("2d") : null;
  const drawTable = new Int8Array(16); // -100 to +100

  function paintDrawCanvas() {
    if (!drawCtx) return;
    const w = drawCv.width, h = drawCv.height;
    drawCtx.clearRect(0, 0, w, h);

    // Center baseline
    drawCtx.strokeStyle = "rgba(255, 255, 255, 0.15)";
    drawCtx.lineWidth = 1;
    drawCtx.beginPath();
    drawCtx.moveTo(0, h / 2);
    drawCtx.lineTo(w, h / 2);
    drawCtx.stroke();

    const barW = (w - 20) / 16;
    for (let i = 0; i < 16; i++) {
      const v = drawTable[i]; // -100..100
      const x = 10 + i * barW;
      const barH = (Math.abs(v) / 100) * (h / 2 - 4);
      const y = v >= 0 ? h / 2 - barH : h / 2;

      drawCtx.fillStyle = "rgba(0, 184, 135, 0.2)";
      drawCtx.fillRect(x + 2, 2, barW - 4, h - 4);

      drawCtx.fillStyle = v >= 0 ? "#00b887" : "#ff6b18";
      drawCtx.fillRect(x + 3, y, barW - 6, Math.max(2, barH));

      // Bar border
      drawCtx.strokeStyle = v >= 0 ? "#1cd69d" : "#ffa060";
      drawCtx.lineWidth = 1;
      drawCtx.strokeRect(x + 3, y, barW - 6, Math.max(2, barH));
    }
  }

  function handleDrawInput(e) {
    if (!drawCv) return;
    const r = drawCv.getBoundingClientRect();
    const clientX = Math.max(r.left, Math.min(r.right, e.clientX));
    const clientY = Math.max(r.top, Math.min(r.bottom, e.clientY));

    const step = Math.min(15, Math.max(0, Math.floor(((clientX - r.left) / r.width) * 16)));
    const relY = (clientY - r.top) / r.height; // 0 (top) to 1 (bottom)
    const amp = Math.round((0.5 - relY) * 200); // +100 to -100
    drawTable[step] = Math.max(-100, Math.min(100, amp));

    paintDrawCanvas();
    // Send Cmd 1 to firmware
    vibe.send(new Uint8Array([1, ...drawTable]));
  }

  if (drawCv) {
    drawCv.addEventListener("pointerdown", (e) => {
      drawCv.setPointerCapture(e.pointerId);
      handleDrawInput(e);
    });
    drawCv.addEventListener("pointermove", (e) => {
      if (e.buttons) handleDrawInput(e);
    });
  }

  document.getElementById("btn-draw-clear").addEventListener("click", () => {
    for (let i = 0; i < 16; i++) {
      drawTable[i] = Math.round(Math.sin((i / 16) * Math.PI * 2) * 90);
    }
    paintDrawCanvas();
    vibe.send(new Uint8Array([1, ...drawTable]));
  });

  /* -------------------------------------------------------------
   * 9. Interactive OSC CHOP (16-Step Mask Pads)
   * ------------------------------------------------------------- */
  const chopPadsBox = document.getElementById("chop-pads");
  const chopMasks = new Uint16Array([0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF]);
  let chopTarget = 0;

  for (let s = 0; s < 16; s++) {
    const pad = document.createElement("button");
    pad.className = "step-pad on";
    pad.textContent = s + 1;
    pad.addEventListener("click", () => {
      const bit = 1 << s;
      chopMasks[chopTarget] ^= bit;
      const mask = chopMasks[chopTarget];
      pad.classList.toggle("on", (mask & bit) !== 0);
      // Send Cmd 3 to firmware: [3, target, mask_lo, mask_hi]
      vibe.send(new Uint8Array([3, chopTarget, mask & 0xFF, (mask >> 8) & 0xFF]));
    });
    chopPadsBox.appendChild(pad);
  }

  function updateChopPadsDisplay() {
    const mask = chopMasks[chopTarget];
    const pads = chopPadsBox.querySelectorAll(".step-pad");
    pads.forEach((pad, s) => {
      pad.classList.toggle("on", (mask & (1 << s)) !== 0);
    });
  }

  const pChopTgt = P("chop_tgt");
  if (pChopTgt) {
    const selChopTgt = document.getElementById("sel-chop_tgt");
    selChopTgt.addEventListener("change", () => {
      chopTarget = parseInt(selChopTgt.value, 10) & 3;
      updateChopPadsDisplay();
    });
  }

  /* -------------------------------------------------------------
   * 10. Bidirectional Data Handler (vibe.onData)
   * ------------------------------------------------------------- */
  vibe.onData((bytes) => {
    if (!bytes || bytes.length === 0) return;
    const cmd = bytes[0];

    // Cmd 2: Draw table from firmware [2, d0..d15]
    if (cmd === 2 && bytes.length >= 17) {
      for (let i = 0; i < 16; i++) {
        drawTable[i] = (bytes[1 + i] << 24) >> 24; // sign extend int8
      }
      paintDrawCanvas();
    }

    // Cmd 4: Chop masks from firmware [4, m0_lo, m0_hi, ...]
    if (cmd === 4 && bytes.length >= 9) {
      for (let i = 0; i < 4; i++) {
        chopMasks[i] = bytes[1 + i * 2] | (bytes[2 + i * 2] << 8);
      }
      updateChopPadsDisplay();
    }
  });

  // Request initial draw table and chop masks from firmware
  vibe.send(new Uint8Array([2]));
  vibe.send(new Uint8Array([4]));

  /* -------------------------------------------------------------
   * 11. Playable Keyboard (C2 to C4)
   * ------------------------------------------------------------- */
  const keysBox = document.getElementById("keys");
  const WHITE_NOTES = [0, 2, 4, 5, 7, 9, 11];
  const BLACK_OFFSETS = { 1: 1, 3: 2, 6: 4, 8: 5, 10: 6 };

  // 2 octaves + top C: 36 (C2) to 60 (C4)
  const startNote = 36;
  const numNotes = 25;

  let whiteCount = 0;
  for (let n = startNote; n < startNote + numNotes; n++) {
    const semi = n % 12;
    if (WHITE_NOTES.includes(semi)) {
      const b = document.createElement("div");
      b.className = "key-white";
      b.dataset.note = n;
      b.addEventListener("pointerdown", (e) => {
        b.setPointerCapture(e.pointerId);
        b.classList.add("active");
        vibe.note(n, 0.85);
      });
      b.addEventListener("pointerup", () => {
        b.classList.remove("active");
        vibe.note(n, 0);
      });
      b.addEventListener("pointerleave", () => {
        if (b.classList.contains("active")) {
          b.classList.remove("active");
          vibe.note(n, 0);
        }
      });
      keysBox.appendChild(b);
      whiteCount++;
    }
  }

  // Black keys
  let wIndex = 0;
  for (let n = startNote; n < startNote + numNotes; n++) {
    const semi = n % 12;
    if (WHITE_NOTES.includes(semi)) {
      wIndex++;
    } else {
      const b = document.createElement("div");
      b.className = "key-black";
      b.dataset.note = n;
      // Position relative to preceding white key
      const leftPct = ((wIndex - 0.35) / 15) * 100;
      b.style.left = leftPct + "%";

      b.addEventListener("pointerdown", (e) => {
        e.stopPropagation();
        b.setPointerCapture(e.pointerId);
        b.classList.add("active");
        vibe.note(n, 0.85);
      });
      b.addEventListener("pointerup", () => {
        b.classList.remove("active");
        vibe.note(n, 0);
      });
      b.addEventListener("pointerleave", () => {
        if (b.classList.contains("active")) {
          b.classList.remove("active");
          vibe.note(n, 0);
        }
      });
      keysBox.appendChild(b);
    }
  }

  /* -------------------------------------------------------------
   * 12. Main Update Loop (vibe.onValues)
   * ------------------------------------------------------------- */
  let curveBusy = false;
  let lastPreset = -1;
  const pPhrType = P("phaser_type");
  const custEls = document.querySelectorAll('[data-cust="1"]');

  vibe.onValues(async (values) => {
    // 1. Update Knobs
    for (const { el, p, valDisplay } of knobs) {
      const v = values[p.i];
      const n = norm(p, v);
      // Map 0..1 to -135deg .. +135deg
      const deg = (n * 270 - 135).toFixed(1);
      el.style.setProperty("--rot", deg + "deg");
      if (valDisplay) valDisplay.textContent = fmt(p, v);
    }

    // 2. Update Selects
    for (const { sel, p } of selects) {
      if (document.activeElement !== sel) {
        const v = values[p.i];
        if (p.choices && p.choices.length > 0) {
          const idx = Math.round(norm(p, v) * (p.choices.length - 1));
          sel.value = idx;
        } else {
          sel.value = Math.round(v);
        }
      }
    }

    // 2b. CUST-only phaser shape knobs (presets override them unless PHR TYP = CUST)
    if (pPhrType && custEls.length) {
      const cust = Math.round(values[pPhrType.i]) === 0;
      custEls.forEach((el) => {
        el.style.opacity = cust ? "1" : "0.35";
        el.style.pointerEvents = cust ? "" : "none";
      });
    }

    // 3. Update Toggle Buttons
    for (const { btn, p } of toggles) {
      const v = Math.round(values[p.i]);
      btn.classList.toggle("active", v !== 0);
      btn.textContent = v !== 0 ? "ON" : "OFF";
    }

    // 4. Update Preset & 7-Segment display
    if (pPreset) {
      const curProg = Math.round(values[pPreset.i]);
      if (document.activeElement !== selPreset) {
        selPreset.value = curProg;
      }
      if (curProg !== lastPreset) {
        lastPreset = curProg;
        const name = (pPreset.choices && pPreset.choices[curProg]) ? pPreset.choices[curProg] : (curProg + 1);
        segDisp.textContent = name;
        // Request updated draw table & chop mask for this preset
        vibe.send(new Uint8Array([2]));
        vibe.send(new Uint8Array([4]));
      }
    }

    // 5. Update HQ Button
    if (pHq) {
      const isHq = Math.round(values[pHq.i]) !== 0;
      btnHq.classList.toggle("active", isHq);
      btnHq.textContent = isHq ? "HQ: ON" : "HQ: OFF";
    }

    // 5b. Update Transpose Quick Displays
    if (pTransp) {
      const v = Math.round(values[pTransp.i]);
      const txt = (v > 0 ? "+" : "") + v + " ST";
      if (valTranspHdr) valTranspHdr.textContent = txt;
      if (valTranspKb) valTranspKb.textContent = txt;
    }

    // 6. Update Curves
    if (!curveBusy) {
      curveBusy = true;
      try {
        await renderCurve("flt-curve", "FILTER", "#ff6b18", "rgba(255, 107, 24, 0.15)");
        await renderCurve("env-curve", "ENVELOPE", "#00b887", "rgba(0, 184, 135, 0.15)");
        await renderCurve("lfo-curve", "LFO", "#3fa9f5", "rgba(63, 169, 245, 0.15)");
      } catch (err) {
        // Curve rendering ignore
      }
      curveBusy = false;
    }
  });

  paintDrawCanvas();
})();

