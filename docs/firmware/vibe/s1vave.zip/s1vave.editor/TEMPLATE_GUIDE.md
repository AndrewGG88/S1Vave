# VIBE Custom UI 6-Panel Grid & Component Boilerplate (`vibe-ui-template.js`)

This guide documents how S1Vave's 6-panel WebView2 / Browser custom editor (`editor/index.html`, `style.css`, and `vibe-ui-template.js`) is structured so other VIBE firmware authors (for example Felucca and community synths) can drop in the same layout and focus purely on their parameter map and DSP features.

## 1. Files Required in Your Firmware's `editor/` Folder

1. `vibe-editor.js` (provided by VIBE SDK 16+)
2. `vibe-ui-template.js` (reusable control binding, conic rotary ring logic, curve canvas renderer, keyboard builder, and SMF MIDI exporter)
3. `style.css` (12-column responsive CSS grid, dark brushed aluminum panels, conic LED collar knobs, 7-segment display, playable keyboard)
4. `index.html` + `app.js` (your synth-specific layout & IDs)

Load order in `index.html`:

```html
<script src="vibe-editor.js"></script>
<script src="vibe-ui-template.js"></script>
<script src="app.js"></script>
```

---

## 2. 12-Column Panel Grid (`style.css`)

Use `<main class="synth-grid">` and give each `<section class="panel col-X">` one of `.col-3`, `.col-4`, `.col-5`, `.col-6`, `.col-7`, `.col-8`, or `.col-12`:

```html
<main class="synth-grid">
  <section class="panel col-4">...</section> <!-- OSC -->
  <section class="panel col-4">...</section> <!-- FILTER -->
  <section class="panel col-4">...</section> <!-- ENV -->
  <section class="panel col-6">...</section> <!-- LFO -->
  <section class="panel col-6">...</section> <!-- FX -->
  <section class="panel col-12">...</section> <!-- TRANSFER / EXTRA -->
</main>
```

---

## 3. Declarative Control Binding

Every rotary knob, dropdown, or toggle automatically binds by its `data-id` attribute matching your firmware's `vibe_param.id` (with optional aliases):

```html
<!-- Knob with illuminated LED collar -->
<div class="control-item">
  <span class="control-label">CUTOFF</span>
  <div class="knob orange" data-id="cutoff"></div>
  <span class="control-val" id="val-cutoff">0</span>
</div>

<!-- Dropdown -->
<select id="sel-lfo_wave" data-id="lfo_wave"></select>

<!-- Toggle -->
<button class="btn" id="btn-lfo_sync">OFF</button>
```

In your `app.js`:

```js
await vibe.ready;
const T = window.VibeUITemplate;
const lookup = T.createParamLookup(vibe, {
  // Optional fallback aliases if DAW IDs differ across firmware revisions
  cutoff: ["cutoff", "filter_cutoff"]
});

const knobCtl = T.bindKnobs(vibe, lookup);
const selCtl = T.bindSelects(vibe, lookup);
const togCtl = T.bindToggles(vibe, lookup, [
  { btnId: "btn-lfo_sync", paramId: "lfo_sync" }
]);

T.buildKeyboard(document.getElementById("keys"), (note, vel) => vibe.note(note, vel), 36, 25);

vibe.onValues(async (values) => {
  knobCtl.update(values);
  selCtl.update(values);
  togCtl.update(values);
  await T.renderCurve(vibe, "flt-curve", "FILTER", "#ff6b18", "rgba(255, 107, 24, 0.15)");
});
```

---

## 4. Visual Accents & Conic Knob Rings

Adding `.orange` or `.blue` to `.knob` and `.panel-title` switches both the pointer glow and conic-gradient collar (`--knob-c`) to S1Vave's tangerine orange or steel blue instead of emerald teal.

---

## 5. Binary Data & Sequence / `.mid` Export Helpers

`VibeUITemplate.patternToMidiBytes(uint8Array, fallbackBpm)` converts a 2116-byte S1Vave `pattern_t` struct into a standard SMF Format 1 `.mid` file (Track 0 tempo/meta, Track 1 = Track A Ch 1, Track 2 = Track B Ch 2, preserving swing, gate/ties, ratchets, and 4-note chords), ready to trigger a download via `VibeUITemplate.triggerDownload(bytes, "pattern.mid", "audio/midi")`.

