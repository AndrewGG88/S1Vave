// SPDX-License-Identifier: GPL-3.0-only
// VIBE Custom Editor Reusable UI & MIDI Export Boilerplate (SDK 16)
// Exposes window.VibeUITemplate so other VIBE firmwares can reuse the
// 6-panel grid, conic LED rotary knobs, curve scopes, keyboard, and SMF .mid export.

(function (global) {
  "use strict";

  function createParamLookup(vibeApi, aliases) {
    const map = aliases || {};
    function find(id) {
      let p = vibeApi.byId(id);
      if (p) return p;
      const al = map[id];
      if (al) {
        for (let i = 0; i < al.length; i++) {
          p = vibeApi.byId(al[i]);
          if (p) return p;
        }
      }
      return undefined;
    }
    function norm(p, v) {
      return p && p.max > p.min ? (v - p.min) / (p.max - p.min) : 0;
    }
    function plain(p, n) {
      return p ? p.min + n * (p.max - p.min) : 0;
    }
    function fmt(p, v) {
      if (p.unit === "st" || p.unit === "cents" || p.unit === "%") {
        return (v > 0 ? "+" : "") + Math.round(v) + (p.unit ? p.unit : "");
      }
      const num = v >= 100 ? v.toFixed(0) : v >= 10 ? v.toFixed(1) : v.toFixed(2);
      return num + (p.unit ? " " + p.unit : "");
    }
    return { find, norm, plain, fmt };
  }

  function applyKnobVisual(el, valDisplay, p, v, normFn, fmtFn) {
    const n = Math.max(0, Math.min(1, normFn(p, v)));
    const deg = (n * 270 - 135).toFixed(1);
    const pct = (n * 100).toFixed(1);
    el.style.setProperty("--rot", deg + "deg");
    el.style.setProperty("--pct", pct);
    if (valDisplay) valDisplay.textContent = fmtFn(p, v);
  }

  function bindKnobs(vibeApi, lookup, root) {
    const scope = root || document;
    const knobElements = scope.querySelectorAll(".knob");
    const knobs = [];

    knobElements.forEach((el) => {
      const id = el.dataset.id;
      const p = lookup.find(id);
      if (!p) return;

      let y0 = 0;
      let v0 = 0;
      const valDisplay = document.getElementById("val-" + id);

      el.addEventListener("pointerdown", (e) => {
        el.setPointerCapture(e.pointerId);
        y0 = e.clientY;
        v0 = vibeApi.values[p.i];
      });

      el.addEventListener("pointermove", (e) => {
        if (!e.buttons) return;
        const fine = e.shiftKey ? 0.2 : 1.0;
        const range = p.max - p.min;
        const delta = ((y0 - e.clientY) / 150) * fine * range;
        const newVal = Math.min(p.max, Math.max(p.min, v0 + delta));
        vibeApi.set(p.i, newVal);
        applyKnobVisual(el, valDisplay, p, newVal, lookup.norm, lookup.fmt);
      });

      el.addEventListener("dblclick", () => {
        vibeApi.set(p.i, p.def);
        applyKnobVisual(el, valDisplay, p, p.def, lookup.norm, lookup.fmt);
      });

      el.addEventListener("wheel", (e) => {
        e.preventDefault();
        const step = p.steps > 1 ? (p.max - p.min) / (p.steps - 1) : 1;
        const delta = (e.deltaY < 0 ? 1 : -1) * (e.shiftKey ? step * 0.2 : step);
        const cur = vibeApi.values[p.i];
        const newVal = Math.min(p.max, Math.max(p.min, cur + delta));
        vibeApi.set(p.i, newVal);
        applyKnobVisual(el, valDisplay, p, newVal, lookup.norm, lookup.fmt);
      }, { passive: false });

      knobs.push({ el, p, valDisplay });
    });

    return {
      knobs,
      update(values) {
        for (let i = 0; i < knobs.length; i++) {
          const k = knobs[i];
          applyKnobVisual(k.el, k.valDisplay, k.p, values[k.p.i], lookup.norm, lookup.fmt);
        }
      }
    };
  }

  function bindSelects(vibeApi, lookup, root) {
    const scope = root || document;
    const selects = [];
    scope.querySelectorAll("select[data-id]").forEach((sel) => {
      const p = lookup.find(sel.dataset.id);
      if (!p) return;
      if (p.choices && p.choices.length > 0) {
        sel.innerHTML = "";
        p.choices.forEach((name, idx) => sel.add(new Option(name, idx)));
      }
      sel.addEventListener("change", () => {
        vibeApi.set(p.i, parseInt(sel.value, 10));
      });
      selects.push({ sel, p });
    });
    return {
      selects,
      update(values) {
        for (let i = 0; i < selects.length; i++) {
          const { sel, p } = selects[i];
          if (document.activeElement !== sel) {
            sel.value = Math.round(values[p.i]);
          }
        }
      }
    };
  }

  function bindToggles(vibeApi, lookup, pairs) {
    const toggles = [];
    pairs.forEach(({ btnId, paramId }) => {
      const btn = document.getElementById(btnId);
      const p = lookup.find(paramId);
      if (!btn || !p) return;
      btn.addEventListener("click", () => {
        const cur = Math.round(vibeApi.values[p.i]);
        vibeApi.set(p.i, cur ? 0 : 1);
      });
      toggles.push({ btn, p });
    });
    return {
      toggles,
      update(values) {
        for (let i = 0; i < toggles.length; i++) {
          const { btn, p } = toggles[i];
          const v = Math.round(values[p.i]);
          btn.classList.toggle("active", v !== 0);
          btn.textContent = v !== 0 ? "ON" : "OFF";
        }
      }
    };
  }

  async function renderCurve(vibeApi, canvasId, cardName, strokeColor, fillColor) {
    const cv = document.getElementById(canvasId);
    if (!cv) return;
    const g = cv.getContext("2d");
    const pts = await vibeApi.curve(cardName);
    if (!pts || !pts.length) return;

    const w = cv.width, h = cv.height;
    g.clearRect(0, 0, w, h);

    g.strokeStyle = "rgba(255, 255, 255, 0.05)";
    g.lineWidth = 1;
    g.beginPath();
    g.moveTo(0, h * 0.5); g.lineTo(w, h * 0.5);
    g.moveTo(w * 0.5, 0); g.lineTo(w * 0.5, h);
    g.stroke();

    g.beginPath();
    for (let k = 0; k < pts.length; k++) {
      const x = (k / (pts.length - 1)) * w;
      const cy = (1 - Math.max(0, Math.min(1, pts[k]))) * (h - 4) + 2;
      if (k === 0) g.moveTo(x, cy);
      else g.lineTo(x, cy);
    }

    if (fillColor) {
      g.lineTo(w, h);
      g.lineTo(0, h);
      g.closePath();
      g.fillStyle = fillColor;
      g.fill();
      g.beginPath();
      for (let k = 0; k < pts.length; k++) {
        const x = (k / (pts.length - 1)) * w;
        const cy = (1 - Math.max(0, Math.min(1, pts[k]))) * (h - 4) + 2;
        if (k === 0) g.moveTo(x, cy);
        else g.lineTo(x, cy);
      }
    }

    g.strokeStyle = strokeColor;
    g.lineWidth = 2;
    g.stroke();
  }

  function buildKeyboard(keysBox, onNote, startNote, numNotes) {
    if (!keysBox) return;
    const sNote = startNote !== undefined ? startNote : 36;
    const nNotes = numNotes !== undefined ? numNotes : 25;
    const WHITE_NOTES = [0, 2, 4, 5, 7, 9, 11];
    keysBox.innerHTML = "";

    let whiteTotal = 0;
    for (let n = sNote; n < sNote + nNotes; n++) {
      if (WHITE_NOTES.includes(n % 12)) whiteTotal++;
    }

    for (let n = sNote; n < sNote + nNotes; n++) {
      if (WHITE_NOTES.includes(n % 12)) {
        const b = document.createElement("div");
        b.className = "key-white";
        b.dataset.note = n;
        b.addEventListener("pointerdown", (e) => {
          b.setPointerCapture(e.pointerId);
          b.classList.add("active");
          onNote(n, 0.85);
        });
        b.addEventListener("pointerup", () => {
          b.classList.remove("active");
          onNote(n, 0);
        });
        b.addEventListener("pointerleave", () => {
          if (b.classList.contains("active")) {
            b.classList.remove("active");
            onNote(n, 0);
          }
        });
        keysBox.appendChild(b);
      }
    }

    let wIndex = 0;
    for (let n = sNote; n < sNote + nNotes; n++) {
      if (WHITE_NOTES.includes(n % 12)) {
        wIndex++;
      } else {
        const b = document.createElement("div");
        b.className = "key-black";
        b.dataset.note = n;
        b.style.left = ((wIndex - 0.35) / whiteTotal) * 100 + "%";
        b.addEventListener("pointerdown", (e) => {
          e.stopPropagation();
          b.setPointerCapture(e.pointerId);
          b.classList.add("active");
          onNote(n, 0.85);
        });
        b.addEventListener("pointerup", () => {
          b.classList.remove("active");
          onNote(n, 0);
        });
        b.addEventListener("pointerleave", () => {
          if (b.classList.contains("active")) {
            b.classList.remove("active");
            onNote(n, 0);
          }
        });
        keysBox.appendChild(b);
      }
    }
  }

  /* -------------------------------------------------------------
   * Standard MIDI File (SMF Format 1) Export for S1Vave pattern_t (2116 B)
   * ------------------------------------------------------------- */
  function writeVarLen(out, val) {
    let v = val >>> 0;
    const buf = [v & 0x7F];
    while ((v >>= 7) > 0) buf.push((v & 0x7F) | 0x80);
    for (let i = buf.length - 1; i >= 0; i--) out.push(buf[i]);
  }

  function makeChunk(tag, dataBytes) {
    const len = dataBytes.length;
    const out = [
      tag.charCodeAt(0), tag.charCodeAt(1), tag.charCodeAt(2), tag.charCodeAt(3),
      (len >>> 24) & 0xFF, (len >>> 16) & 0xFF, (len >>> 8) & 0xFF, len & 0xFF
    ];
    for (let i = 0; i < len; i++) out.push(dataBytes[i]);
    return out;
  }

  function encodeTrackEvents(events) {
    events.sort((a, b) => a.tick - b.tick || a.order - b.order);
    const body = [];
    let prevTick = 0;
    for (let i = 0; i < events.length; i++) {
      const ev = events[i];
      const dt = Math.max(0, ev.tick - prevTick);
      prevTick = ev.tick;
      writeVarLen(body, dt);
      for (let j = 0; j < ev.bytes.length; j++) body.push(ev.bytes[j]);
    }
    writeVarLen(body, 0);
    body.push(0xFF, 0x2F, 0x00); // End of Track
    return makeChunk("MTrk", body);
  }

  function patternToMidiBytes(patBytes, fallbackBpm) {
    if (!patBytes || patBytes.length < 2112) {
      throw new Error("Invalid pattern buffer");
    }
    const dv = new DataView(patBytes.buffer, patBytes.byteOffset, patBytes.byteLength);
    const magic = dv.getUint32(0, true);
    if (magic !== 0x31535653) {
      throw new Error("Invalid pattern magic (expected SVS1)");
    }

    const PPQ = 480;
    const DIV_PER_Q = [1, 2, 4, 8, 3, 6]; // D_4, D_8, D_16, D_32, D_8T, D_16T
    const SEQ_STEPS = 256;
    const GATE_TIE = 127;
    const STEP_OFF = 0x80;

    let bpm = patBytes[2111];
    if (bpm < 40 || bpm > 240) bpm = fallbackBpm || 120;
    const usPerQuarter = Math.round(60000000 / bpm);

    // Tempo & Track Name Meta Track
    const metaEvents = [
      { tick: 0, order: 0, bytes: [0xFF, 0x03, 11, 83, 49, 86, 97, 118, 101, 32, 83, 121, 110, 99] },
      { tick: 0, order: 1, bytes: [0xFF, 0x51, 0x03, (usPerQuarter >> 16) & 0xFF, (usPerQuarter >> 8) & 0xFF, usPerQuarter & 0xFF] }
    ];

    const midiTracks = [encodeTrackEvents(metaEvents)];

    for (let t = 0; t < 2; t++) {
      const trkOff = 4 + t * 8;
      const len = dv.getUint16(trkOff, true);
      if (!len) continue;
      const divIdx = Math.min(5, patBytes[trkOff + 2]);
      const swing = Math.max(50, Math.min(75, patBytes[trkOff + 3] || 50));
      const transp = dv.getInt8(trkOff + 4);
      const stepTicks = (PPQ * 4) / (DIV_PER_Q[divIdx] * 4); // wait: 1 quarter = PPQ, so step = PPQ / DIV_PER_Q
      const baseStepTicks = PPQ / DIV_PER_Q[divIdx];

      const events = [];
      const trkName = t === 0 ? "S1Vave Track A" : "S1Vave Track B";
      const nameBytes = [0xFF, 0x03, trkName.length];
      for (let i = 0; i < trkName.length; i++) nameBytes.push(trkName.charCodeAt(i));
      events.push({ tick: 0, order: 0, bytes: nameBytes });

      function getStep(i) {
        const slot = t === 0 ? i : (SEQ_STEPS - 1 - i);
        const off = 20 + slot * 8;
        return {
          notes: [patBytes[off], patBytes[off + 1], patBytes[off + 2], patBytes[off + 3]],
          vel: patBytes[off + 4] || 100,
          gate: patBytes[off + 5] || 96,
          ratch: patBytes[off + 6],
          chance: patBytes[off + 7]
        };
      }

      // Compute exact swung start ticks for steps 0..len
      const stepStart = new Array(len + 1);
      stepStart[0] = 0;
      for (let i = 0; i < len; i += 2) {
        const pairTicks = baseStepTicks * 2;
        const firstDur = (pairTicks * swing) / 100;
        const secondDur = pairTicks - firstDur;
        stepStart[i + 1] = stepStart[i] + firstDur;
        if (i + 2 <= len) stepStart[i + 2] = stepStart[i + 1] + secondDur;
      }

      const activeTies = new Set();

      for (let i = 0; i < len; i++) {
        const st = getStep(i);
        const t0 = Math.round(stepStart[i]);
        const t1 = Math.round(stepStart[i + 1]);
        const dur = Math.max(12, t1 - t0);
        const isOff = (st.ratch & STEP_OFF) !== 0;

        if (isOff) {
          activeTies.forEach((n) => {
            events.push({ tick: t0, order: 1, bytes: [0x80 | t, n, 0] });
          });
          activeTies.clear();
          continue;
        }

        const stepNotes = [];
        for (let k = 0; k < 4; k++) {
          if (st.notes[k]) {
            const nn = Math.max(0, Math.min(127, st.notes[k] + transp));
            stepNotes.push(nn);
          }
        }

        // Release tied notes not continued on this step
        activeTies.forEach((n) => {
          if (!stepNotes.includes(n)) {
            events.push({ tick: t0, order: 1, bytes: [0x80 | t, n, 0] });
            activeTies.delete(n);
          }
        });

        if (stepNotes.length === 0) continue;

        const ratchCount = (st.ratch & 3) + 1;
        const vel = Math.max(1, Math.min(127, st.vel));
        const isTie = st.gate === GATE_TIE && i + 1 < len;

        if (ratchCount > 1) {
          const subDur = dur / ratchCount;
          const subOn = Math.max(8, Math.round(subDur * (st.gate / 127)));
          for (let r = 0; r < ratchCount; r++) {
            const rt0 = Math.round(t0 + r * subDur);
            const rt1 = (isTie && r === ratchCount - 1) ? t1 : Math.min(t1 - 1, rt0 + subOn);
            for (const nn of stepNotes) {
              events.push({ tick: rt0, order: 2, bytes: [0x90 | t, nn, vel] });
              if (!(isTie && r === ratchCount - 1)) {
                events.push({ tick: Math.max(rt0 + 4, rt1), order: 1, bytes: [0x80 | t, nn, 0] });
              } else {
                activeTies.add(nn);
              }
            }
          }
        } else {
          const gateTicks = Math.max(8, Math.round((dur * Math.max(8, st.gate)) / 127));
          for (const nn of stepNotes) {
            if (!activeTies.has(nn)) {
              events.push({ tick: t0, order: 2, bytes: [0x90 | t, nn, vel] });
            }
            if (isTie) {
              activeTies.add(nn);
            } else {
              events.push({ tick: Math.min(t1 - 1, t0 + gateTicks), order: 1, bytes: [0x80 | t, nn, 0] });
              activeTies.delete(nn);
            }
          }
        }
      }

      // Close any dangling tied notes at pattern end
      const endTick = Math.round(stepStart[len]);
      activeTies.forEach((nn) => {
        events.push({ tick: endTick, order: 1, bytes: [0x80 | t, nn, 0] });
      });

      midiTracks.push(encodeTrackEvents(events));
      void stepTicks;
    }

    const numTracks = midiTracks.length;
    const header = makeChunk("MThd", [
      0x00, 0x01,                         // Format 1
      (numTracks >> 8) & 0xFF, numTracks & 0xFF,
      (PPQ >> 8) & 0xFF, PPQ & 0xFF
    ]);

    const totalLen = header.length + midiTracks.reduce((acc, tr) => acc + tr.length, 0);
    const out = new Uint8Array(totalLen);
    out.set(header, 0);
    let pos = header.length;
    for (const tr of midiTracks) {
      out.set(tr, pos);
      pos += tr.length;
    }
    return out;
  }

  function triggerDownload(bytes, filename, mime) {
    const blob = new Blob([bytes], { type: mime || "application/octet-stream" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
  }

  async function promptSaveFile(suggestedName, description, mime, ext, folderHint) {
    const inIframe = (function () {
      try { return window.self !== window.top; } catch (e) { return true; }
    })();

    if (!inIframe && typeof window.showSaveFilePicker === "function") {
      try {
        const accept = {};
        accept[mime || "application/octet-stream"] = [ext || ".bin"];
        const handle = await window.showSaveFilePicker({
          suggestedName: suggestedName,
          types: [{ description: description || "S1Vave File", accept: accept }]
        });
        return { handle: handle, name: handle.name || suggestedName };
      } catch (err) {
        if (err && err.name === "AbortError") return null;
      }
    }

    return new Promise((resolve) => {
      if (!document.getElementById("vibe-save-modal-style")) {
        const st = document.createElement("style");
        st.id = "vibe-save-modal-style";
        st.textContent =
          "#vibe-save-modal{position:fixed;inset:0;z-index:9999;background:rgba(10,12,14,0.78);display:flex;align-items:center;justify-content:center;padding:16px;font-family:inherit}" +
          "#vibe-save-modal .vsm-box{width:100%;max-width:420px;background:#1d2022;border:1px solid #00b887;border-radius:8px;padding:14px 16px;box-shadow:0 12px 32px rgba(0,0,0,0.65);color:#e6eaec}" +
          "#vibe-save-modal .vsm-hdr{font-size:12px;font-weight:700;letter-spacing:0.08em;color:#1cd69d;margin-bottom:8px;text-transform:uppercase}" +
          "#vibe-save-modal .vsm-dir{font-size:11px;color:#b8c2c7;background:#121416;border:1px solid #2c3135;border-radius:4px;padding:6px 8px;margin-bottom:10px;word-break:break-all}" +
          "#vibe-save-modal .vsm-dir strong{color:#ffd424}" +
          "#vibe-save-modal label{display:block;font-size:11px;color:#9aa4aa;margin-bottom:4px}" +
          "#vibe-save-modal input{width:100%;box-sizing:border-box;background:#101214;color:#ffffff;border:1px solid #394045;border-radius:4px;padding:7px 9px;font-size:13px;outline:none}" +
          "#vibe-save-modal input:focus{border-color:#00b887}" +
          "#vibe-save-modal .vsm-btns{display:flex;justify-content:flex-end;gap:8px;margin-top:12px}" +
          "#vibe-save-modal button{padding:6px 14px;border-radius:4px;font-size:11px;font-weight:700;letter-spacing:0.05em;cursor:pointer;border:1px solid #3a4045;background:#272c30;color:#d6dce0}" +
          "#vibe-save-modal button.vsm-ok{background:#00b887;border-color:#1cd69d;color:#0b1110}";
        document.head.appendChild(st);
      }

      const prev = document.getElementById("vibe-save-modal");
      if (prev) prev.remove();

      const overlay = document.createElement("div");
      overlay.id = "vibe-save-modal";
      const box = document.createElement("div");
      box.className = "vsm-box";

      const hdr = document.createElement("div");
      hdr.className = "vsm-hdr";
      hdr.textContent = description || "Save File";
      box.appendChild(hdr);

      if (inIframe || folderHint) {
        const dir = document.createElement("div");
        dir.className = "vsm-dir";
        const pathTxt = folderHint || "Music\\VIBE FM\\s1vave\\";
        dir.innerHTML = "Save folder: <strong></strong>";
        dir.querySelector("strong").textContent = pathTxt;
        box.appendChild(dir);
      }

      const lbl = document.createElement("label");
      lbl.textContent = "Filename:";
      box.appendChild(lbl);

      const inp = document.createElement("input");
      inp.type = "text";
      inp.value = suggestedName || "s1vave.bin";
      box.appendChild(inp);

      const btns = document.createElement("div");
      btns.className = "vsm-btns";
      const btnCancel = document.createElement("button");
      btnCancel.type = "button";
      btnCancel.textContent = "CANCEL";
      const btnOk = document.createElement("button");
      btnOk.type = "button";
      btnOk.className = "vsm-ok";
      btnOk.textContent = "SAVE";
      btns.appendChild(btnCancel);
      btns.appendChild(btnOk);
      box.appendChild(btns);
      overlay.appendChild(box);
      document.body.appendChild(overlay);

      let done = false;
      function finish(val) {
        if (done) return;
        done = true;
        document.removeEventListener("keydown", onKey, true);
        overlay.remove();
        resolve(val);
      }
      function submit() {
        const clean = (inp.value || "").trim() || suggestedName;
        finish({ handle: null, name: clean });
      }
      function onKey(e) {
        if (e.key === "Escape") { e.preventDefault(); finish(null); }
        else if (e.key === "Enter") { e.preventDefault(); submit(); }
      }

      btnCancel.addEventListener("click", () => finish(null));
      btnOk.addEventListener("click", submit);
      overlay.addEventListener("click", (e) => { if (e.target === overlay) finish(null); });
      document.addEventListener("keydown", onKey, true);
      setTimeout(() => { inp.focus(); inp.select(); }, 0);
    });
  }

  async function finishSaveFile(target, bytes, mime) {
    const name = (target && target.name) ? target.name : "s1vave_export.bin";
    if (target && target.handle) {
      const writable = await target.handle.createWritable();
      await writable.write(bytes);
      await writable.close();
      return name;
    }
    triggerDownload(bytes, name, mime);
    return name;
  }

  global.VibeUITemplate = {
    createParamLookup,
    bindKnobs,
    bindSelects,
    bindToggles,
    renderCurve,
    buildKeyboard,
    patternToMidiBytes,
    triggerDownload,
    promptSaveFile,
    finishSaveFile
  };
})(window);

